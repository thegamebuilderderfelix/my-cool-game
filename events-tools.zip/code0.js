gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.GDplayerObjects1= [];
gdjs.Untitled_32sceneCode.GDplayerObjects2= [];
gdjs.Untitled_32sceneCode.GDbaseworldtilemapObjects1= [];
gdjs.Untitled_32sceneCode.GDbaseworldtilemapObjects2= [];
gdjs.Untitled_32sceneCode.GDNewParticlesEmitterObjects1= [];
gdjs.Untitled_32sceneCode.GDNewParticlesEmitterObjects2= [];
gdjs.Untitled_32sceneCode.GDtreebackdropObjects1= [];
gdjs.Untitled_32sceneCode.GDtreebackdropObjects2= [];
gdjs.Untitled_32sceneCode.GDcloudsObjects1= [];
gdjs.Untitled_32sceneCode.GDcloudsObjects2= [];
gdjs.Untitled_32sceneCode.GDbluebackground_9595_9595Objects1= [];
gdjs.Untitled_32sceneCode.GDbluebackground_9595_9595Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2= [];


gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 4, "", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Untitled_32sceneCode.GDplayerObjects1.length !== 0 ? gdjs.Untitled_32sceneCode.GDplayerObjects1[0] : null), true, "", 0);
}}

}


};gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

};gdjs.Untitled_32sceneCode.asyncCallback79983956 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects2);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects2[i].getBehavior("Tween").addObjectScaleXTween2("ResetStretchX", 1, "easeInQuad", 0.10, false, true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects2[i].getBehavior("Tween").addObjectScaleYTween2("ResetStretchY", 1, "easeInQuad", 0.10, false, true);
}
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
for (const obj of gdjs.Untitled_32sceneCode.GDplayerObjects1) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.150), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback79983956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback81517724 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects2);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects2[i].getBehavior("Tween").addObjectScaleXTween2("ResetStretchX", 1, "easeInQuad", 0.10, false, true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects2[i].getBehavior("Tween").addObjectScaleYTween2("ResetStretchY", 1, "easeInQuad", 0.10, false, true);
}
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
for (const obj of gdjs.Untitled_32sceneCode.GDplayerObjects1) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.150), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback81517724(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.eventsList4 = function(runtimeScene) {

};gdjs.Untitled_32sceneCode.eventsList5 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDplayerObjects1[k] = gdjs.Untitled_32sceneCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(79908100);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getBehavior("Tween").addObjectScaleXTween2("stretchX", 0.7, "easeInQuad", 0.10, false, true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getBehavior("Tween").addObjectScaleYTween2("stretchY", 1.3, "easeInQuad", 0.10, false, true);
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDplayerObjects1[k] = gdjs.Untitled_32sceneCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(71649412);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getBehavior("Tween").addObjectScaleXTween2("SquishX", 1.3, "easeOutQuad", 0.10, false, true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getBehavior("Tween").addObjectScaleYTween2("SquishY", 0.7, "easeOutQuad", 0.10, false, true);
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


gdjs.Untitled_32sceneCode.eventsList4(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDplayerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDplayerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbaseworldtilemapObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbaseworldtilemapObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtreebackdropObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtreebackdropObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDcloudsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDcloudsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbluebackground_9595_9595Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDbluebackground_9595_9595Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList5(runtimeScene);
gdjs.Untitled_32sceneCode.GDplayerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDplayerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbaseworldtilemapObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbaseworldtilemapObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtreebackdropObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtreebackdropObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDcloudsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDcloudsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbluebackground_9595_9595Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDbluebackground_9595_9595Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
